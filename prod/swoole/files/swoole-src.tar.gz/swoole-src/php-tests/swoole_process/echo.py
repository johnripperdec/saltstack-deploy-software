import sys

def main():
	s = raw_input()
	print "Python: " + s

main()

require('flot');
require('flotTime');
require('flotCrosshair');
require('flotSelection');
require('flotSymbol');
require('flotStack');
require('flotAxisLabels');

# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-01-11T20:36:32+00:00", "build_sha"=>"1da2b64c9ca1df74cba80ae8fe4f476e69578733", "build_snapshot"=>false}